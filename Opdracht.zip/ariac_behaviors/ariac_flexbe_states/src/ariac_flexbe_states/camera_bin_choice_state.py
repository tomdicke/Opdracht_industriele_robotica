#!/usr/bin/env python
import rospy

from flexbe_core import EventState, Logger


class CameraBinChoiceState(EventState):
	'''
	State for deciding witch bin and camera will be used
	<# agv_id		string		AGV ID
	<# bin_location		StorageUnit[]	Bin of part	
	#> overzet_type		string		overzet van LR of RL of not
	#> agv_predrop		string		AGV pre drop positie van juiste AGV
	#> camera_topic		StorageUnit[]	Camera topic
	#> camera_frame		StorageUnit[]	Camera frame
	#> camera_ref_frame	StorageUnit[]	Camera ref_frame
	#> config_name		string		Positie voor part oppakken
	#> arm_id_pre		string		Arm id voor de gripper
	#> move_group_prefix	string		Arm nummer te gebruiken
	<= continue			Alle waardes zijn vastgelegd
	<= invalid_bin 			Invalid bin number

	'''

	def __init__(self):
		# Declare outcomes, input_keys, and output_keys by calling the super constructor with the corresponding arguments.
		super(CameraBinChoiceState, self).__init__(input_keys = ['bin_location','agv_id'], outcomes = ['continue', 'invalid_bin'], output_keys = ['overzet_type','camera_ref_frame','agv_predrop','camera_frame','arm_id_pre','camera_topic','config_name','move_group_prefix'])

		
		pass # Nothing to do in this example.


	def execute(self, userdata):
		# This method is called periodically while the state is active.
		# Main purpose is to check state conditions and trigger a corresponding outcome.
		# If no outcome is returned, the state will stay active.

		if userdata.bin_location == "bin1":
			camera_topic = '/ariac/logical_camera_5'
			camera_frame = 'logical_camera_5_frame'
			camera_ref_frame = 'arm1_linear_arm_actuator'
			config_name = "bin1PreGrasp"
			move_group_prefix = "/ariac/arm1"
			arm_id_pre = 'arm1'
			if userdata.agv_id == 'agv1':
				overzet_type = 'not'
				agv_predrop = "tray1PreDrop"
				return 'continue'
			else:
				overzet_type = 'LR'
				agv_predrop = "tray2PreDrop"
				return 'continue'
							
		elif userdata.bin_location == "bin2":
			camera_topic = '/ariac/logical_camera_4'
			camera_frame = 'logical_camera_4_frame'
			camera_ref_frame = 'arm1_linear_arm_actuator'
			config_name = "bin2PreGrasp"
			move_group_prefix = "/ariac/arm1"
			arm_id_pre = 'arm1'
			if userdata.agv_id == 'agv1':
				overzet_type = 'not'
				agv_predrop = "tray1PreDrop"
				return 'continue'
			else:
				overzet_type = 'LR'
				agv_predrop = "tray2PreDrop"
				return 'continue'

		elif userdata.bin_location == "bin3":
			camera_topic = '/ariac/logical_camera_6'
			camera_frame = 'logical_camera_6_frame'
			camera_ref_frame = ''
			return 'continue'

		elif userdata.bin_location == "bin4":
			camera_topic = '/ariac/logical_camera_7'
			camera_frame = 'logical_camera_7_frame'
			camera_ref_frame = ''
			return 'continue'

		elif userdata.bin_location == "bin5":
			camera_ref_frame = 'arm2_linear_arm_actuator'
			camera_topic = '/ariac/logical_camera_8'
			camera_frame = 'logical_camera_8_frame'
			config_name = "bin5PreGrasp"
			move_group_prefix = "/ariac/arm2"
			arm_id_pre = 'arm2'
			if userdata.agv_id == 'agv2':
				overzet_type = 'not'
				agv_predrop = "tray2PreDrop"
				return 'continue'
			else:
				overzet_type = 'RL'
				agv_predrop = "tray1PreDrop"
				return 'continue'

		elif userdata.bin_location == "bin6":
			camera_ref_frame = 'arm2_linear_arm_actuator'
			camera_topic = '/ariac/logical_camera_9'
			camera_frame = 'logical_camera_9_frame'
			move_group_prefix = "/ariac/arm2"
			arm_id_pre = 'arm2'
			config_name = 'bin6PreGrasp'
			if userdata.agv_id == 'agv2':
				overzet_type = 'not'
				agv_predrop = "tray2PreDrop"		
				return 'continue'
			else:
				overzet_type = 'RL'
				agv_predrop = "tray1PreDrop"
				return 'continue'
		else:
			return 'invalid_bin'
		
		pass # Nothing to do in this example.

	def on_enter(self, userdata):
		# This method is called when the state becomes active, i.e. a transition from another state to this one is taken.
		# It is primarily used to start actions which are associated with this state.

		# The following code is just for illustrating how the behavior logger works.
		# Text logged by the behavior logger is sent to the operator and displayed in the GUI.

		pass # Nothing to do in this example.


	def on_exit(self, userdata):
		# This method is called when an outcome is returned and another state gets active.
		# It can be used to stop possibly running processes started by on_enter.

		pass # Nothing to do in this example.


	def on_start(self):
		# This method is called when the behavior is started.
		# If possible, it is generally better to initialize used resources in the constructor
		# because if anything failed, the behavior would not even be started.

		# In this example, we use this event to set the correct start time.
		pass # Nothing to do in this example.


	def on_stop(self):
		# This method is called whenever the behavior stops execution, also if it is cancelled.
		# Use this event to clean up things like claimed resources.

		pass # Nothing to do in this example.
		
