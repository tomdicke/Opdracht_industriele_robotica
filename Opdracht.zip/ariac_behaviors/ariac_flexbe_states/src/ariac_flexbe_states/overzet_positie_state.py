#!/usr/bin/env python
import rospy

from flexbe_core import EventState, Logger


class OverzetPositieState(EventState):
	'''
	Example for a state to demonstrate which functionality is available for state implementation.
	This example lets the behavior wait until the given target_time has passed since the behavior has been started.
	#> predrop1		string		overzet van LR of RL of not
	#> pregrasp1		string		overzet van LR of RL of not
	#> arm_id_drop		string		Deze arm zet de part in overzetbin
	#> arm_id_grasp		string		Deze arm pakt part uit overzetbin
	#> drop_position	string		Plek voor part los te laten
	#> camera_topic_overzet		StorageUnit[]	Camera topic
	#> camera_frame_overzet		StorageUnit[]	Camera frame
	#> camera_ref_frame_overzet	StorageUnit[]	Camera ref_frame

	<# overzet_type		string		overzet van LR of RL of not
	<= overzet_begin			Overzet van rechts naar links
	<= invalid_overzet		Example for a failure outcome.
	 
	'''

	def __init__(self):
		# Declare outcomes, input_keys, and output_keys by calling the super constructor with the corresponding arguments.
		super(OverzetPositieState, self).__init__(input_keys = ['overzet_type'],output_keys = ['drop_position','camera_topic_overzet','camera_frame_overzet','camera_ref_frame_overzet','predrop1','pregrasp1','arm_id_drop','arm_id_grasp'],outcomes = ['overzet_begin','invalid_overzet'])

		# Store state parameter for later use.
		

		# The constructor is called when building the state machine, not when actually starting the behavior.
		# Thus, we cannot save the starting time now and will do so later.
		
		pass # Nothing to do in this example.

	def execute(self, userdata):
		# This method is called periodically while the state is active.
		# Main purpose is to check state conditions and trigger a corresponding outcome.
		# If no outcome is returned, the state will stay active.

		if userdata.overzet_type == 'LR':
			predrop1 = 'bin3PreGraspARM1'
			pregrasp1 = 'bin3PreGraspARM2'
			arm_id_drop = 'arm1'
			arm_id_grasp = 'arm2'
			drop_position = 'bin3PreDrop'
			camera_topic_overzet = '/ariac/logical_camera_6'
			camera_frame_overzet = 'logical_camera_6_frame'
			camera_ref_frame_overzet = 'arm1_linear_arm_actuator'
			return 'overzet_begin'

		elif userdata.overzet_type == 'RL':
			predrop1 = 'bin4PreGraspARM2'
			pregrasp1 = 'bin4PreGraspARM2'
			arm_id_drop = 'arm2'
			arm_id_grasp = 'arm1'
			drop_position = 'bin4PreDrop'
			camera_topic_overzet = '/ariac/logical_camera_7'
			camera_frame_overzet = 'logical_camera_7_frame'
			camera_ref_frame_overzet = 'arm2_linear_arm_actuator'
			return 'overzet_begin'
		else: 
			return 'invalid_overzet'
		
		pass # Nothing to do in this example.

	def on_enter(self, userdata):
		# This method is called when the state becomes active, i.e. a transition from another state to this one is taken.
		# It is primarily used to start actions which are associated with this state.

		# The following code is just for illustrating how the behavior logger works.
		# Text logged by the behavior logger is sent to the operator and displayed in the GUI.

		
		pass # Nothing to do in this example.

	def on_exit(self, userdata):
		# This method is called when an outcome is returned and another state gets active.
		# It can be used to stop possibly running processes started by on_enter.

		pass # Nothing to do in this example.


	def on_start(self):
		# This method is called when the behavior is started.
		# If possible, it is generally better to initialize used resources in the constructor
		# because if anything failed, the behavior would not even be started.

		# In this example, we use this event to set the correct start time.
		pass # Nothing to do in this example.


	def on_stop(self):
		# This method is called whenever the behavior stops execution, also if it is cancelled.
		# Use this event to clean up things like claimed resources.

		pass # Nothing to do in this example.
		
