#!/usr/bin/env python
# -*- coding: utf-8 -*-
###########################################################
#               WARNING: Generated code!                  #
#              **************************                 #
# Manual changes may get lost if file is generated again. #
# Only code inside the [MANUAL] tags will be kept.        #
###########################################################

from flexbe_core import Behavior, Autonomy, OperatableStateMachine, ConcurrencyContainer, PriorityContainer, Logger
from ariac_logistics_flexbe_states.get_material_locations import GetMaterialLocationsState
from flexbe_states.wait_state import WaitState
from ariac_flexbe_states.detect_part_camera_ariac_state import DetectPartCameraAriacState
from ariac_flexbe_states.moveit_to_joints_dyn_ariac_state import MoveitToJointsDynAriacState
from ariac_flexbe_states.vacuum_gripper_control_state import VacuumGripperControlState
from ariac_flexbe_states.message_state import MessageState
from ariac_support_flexbe_states.get_item_from_list_state import GetItemFromListState
from ariac_flexbe_states.camera_bin_choice_state import CameraBinChoiceState
from ariac_flexbe_states.srdf_state_to_moveit_ariac_state import SrdfStateToMoveitAriac
from ariac_flexbe_states.overzet_positie_state import OverzetPositieState
from ariac_flexbe_states.set_conveyorbelt_power_state import SetConveyorbeltPowerState
from ariac_flexbe_states.compute_grasp_ariac_state import ComputeGraspAriacState
from ariac_support_flexbe_states.equal_state import EqualState
from ariac_flexbe_states.compute_grasp_partoffset_ariac_state import ComputeGraspPartOffsetAriacState
from ariac_support_flexbe_states.replace_state import ReplaceState
# Additional imports can be added inside the following tags
# [MANUAL_IMPORT]

# [/MANUAL_IMPORT]


'''
Created on Wed Apr 22 2020
@author: Gerard Harkema
'''
class transport_part_form_bin_to_agv_stateSM(Behavior):
	'''
	transports part from it's bin to the selected agv
	'''


	def __init__(self):
		super(transport_part_form_bin_to_agv_stateSM, self).__init__()
		self.name = 'transport_part_form_bin_to_agv_state'

		# parameters of this behavior

		# references to used behaviors

		# Additional initialization code can be added inside the following tags
		# [MANUAL_INIT]
		
		# [/MANUAL_INIT]

		# Behavior comments:



	def create(self):
		# x:52 y:611, x:930 y:336
		_state_machine = OperatableStateMachine(outcomes=['finished', 'failed'], input_keys=['part_type', 'agv_id', 'pose_on_agv'])
		_state_machine.userdata.agv_id = ''
		_state_machine.userdata.part_type = ''
		_state_machine.userdata.pose_on_agv = []
		_state_machine.userdata.part_pick_pose = []
		_state_machine.userdata.part_pose = []
		_state_machine.userdata.joint_values = []
		_state_machine.userdata.joint_names = []
		_state_machine.userdata.offset = 0.1
		_state_machine.userdata.move_group = 'manipulator'
		_state_machine.userdata.move_group_prefix = ''
		_state_machine.userdata.config_name_home = 'home'
		_state_machine.userdata.robot_name = ''
		_state_machine.userdata.camera_ref_frame = ''
		_state_machine.userdata.camera_topic = ''
		_state_machine.userdata.camera_frame = ''
		_state_machine.userdata.tool_link = 'ee_link'
		_state_machine.userdata.agv_pose = []
		_state_machine.userdata.part_offset = 0.035
		_state_machine.userdata.part_rotation = 0
		_state_machine.userdata.conveyor_belt_power = 100.0
		_state_machine.userdata.part_drop_offset = 0.1
		_state_machine.userdata.StartText = 'Opdracht gestart'
		_state_machine.userdata.StopText = 'Opdracht gestopt'
		_state_machine.userdata.Shipments = []
		_state_machine.userdata.material_locations = ''
		_state_machine.userdata.NumberOfShipments = 0
		_state_machine.userdata.OrderId = ''
		_state_machine.userdata.Products = []
		_state_machine.userdata.NumberOfProducts = 0
		_state_machine.userdata.MaterialsLocationList = []
		_state_machine.userdata.part = ''
		_state_machine.userdata.zero_value = 0
		_state_machine.userdata.material_locations = []
		_state_machine.userdata.overzet_not = 'not'
		_state_machine.userdata.overzet_type = ''
		_state_machine.userdata.arm_id_pre = ''
		_state_machine.userdata.config_name = ''
		_state_machine.userdata.camera_ref_frame_overzet = ''
		_state_machine.userdata.camera_topic_overzet = ''
		_state_machine.userdata.camera_frame_overzet = ''
		_state_machine.userdata.agv_predrop = ''
		_state_machine.userdata.action_topic = '/move_group'

		# Additional creation code can be added inside the following tags
		# [MANUAL_CREATE]
		
		# [/MANUAL_CREATE]


		with _state_machine:
			# x:41 y:37
			OperatableStateMachine.add('GetPartLocation',
										GetMaterialLocationsState(),
										transitions={'continue': 'GetBinLocation'},
										autonomy={'continue': Autonomy.Off},
										remapping={'part': 'part_type', 'material_locations': 'material_locations'})

			# x:626 y:100
			OperatableStateMachine.add('WaitRetry1',
										WaitState(wait_time=5),
										transitions={'done': 'MovePreGrasp1'},
										autonomy={'done': Autonomy.Off})

			# x:781 y:17
			OperatableStateMachine.add('DetectCameraPart',
										DetectPartCameraAriacState(time_out=5.0),
										transitions={'continue': 'ComputePick', 'failed': 'failed', 'not_found': 'failed'},
										autonomy={'continue': Autonomy.Off, 'failed': Autonomy.Off, 'not_found': Autonomy.Off},
										remapping={'ref_frame': 'camera_ref_frame', 'camera_topic': 'camera_topic', 'camera_frame': 'camera_frame', 'part': 'part_type', 'pose': 'part_pick_pose'})

			# x:1654 y:57
			OperatableStateMachine.add('Wait',
										WaitState(wait_time=1),
										transitions={'done': 'MovePreGrasp2'},
										autonomy={'done': Autonomy.Off})

			# x:1196 y:87
			OperatableStateMachine.add('WaitRetry3',
										WaitState(wait_time=5),
										transitions={'done': 'MoveToPick1'},
										autonomy={'done': Autonomy.Off})

			# x:1195 y:15
			OperatableStateMachine.add('MoveToPick1',
										MoveitToJointsDynAriacState(),
										transitions={'reached': 'EnableGripper', 'planning_failed': 'WaitRetry3', 'control_failed': 'EnableGripper'},
										autonomy={'reached': Autonomy.Off, 'planning_failed': Autonomy.Off, 'control_failed': Autonomy.Off},
										remapping={'move_group_prefix': 'move_group_prefix', 'move_group': 'move_group', 'action_topic': 'action_topic', 'joint_values': 'joint_values', 'joint_names': 'joint_names'})

			# x:1438 y:19
			OperatableStateMachine.add('EnableGripper',
										VacuumGripperControlState(enable=True),
										transitions={'continue': 'Wait', 'failed': 'failed', 'invalid_arm_id': 'failed'},
										autonomy={'continue': Autonomy.Off, 'failed': Autonomy.Off, 'invalid_arm_id': Autonomy.Off},
										remapping={'arm_id': 'arm_id_pre'})

			# x:164 y:451
			OperatableStateMachine.add('DisableGripper',
										VacuumGripperControlState(enable=False),
										transitions={'continue': 'finished', 'failed': 'failed', 'invalid_arm_id': 'failed'},
										autonomy={'continue': Autonomy.Off, 'failed': Autonomy.Off, 'invalid_arm_id': Autonomy.Off},
										remapping={'arm_id': 'arm_id_drop'})

			# x:36 y:182
			OperatableStateMachine.add('AgvIDMessage',
										MessageState(),
										transitions={'continue': 'PartTypeMessage'},
										autonomy={'continue': Autonomy.Off},
										remapping={'message': 'agv_id'})

			# x:32 y:245
			OperatableStateMachine.add('PartTypeMessage',
										MessageState(),
										transitions={'continue': 'PoseMessage'},
										autonomy={'continue': Autonomy.Off},
										remapping={'message': 'part_type'})

			# x:32 y:308
			OperatableStateMachine.add('PoseMessage',
										MessageState(),
										transitions={'continue': 'BinLocation'},
										autonomy={'continue': Autonomy.Off},
										remapping={'message': 'pose_on_agv'})

			# x:27 y:105
			OperatableStateMachine.add('GetBinLocation',
										GetItemFromListState(),
										transitions={'done': 'AgvIDMessage', 'invalid_index': 'failed'},
										autonomy={'done': Autonomy.Off, 'invalid_index': Autonomy.Off},
										remapping={'list': 'material_locations', 'index': 'zero_value', 'item': 'bin_location'})

			# x:437 y:78
			OperatableStateMachine.add('CameraBinChoice',
										CameraBinChoiceState(),
										transitions={'continue': 'MovePreGrasp1', 'invalid_bin': 'failed'},
										autonomy={'continue': Autonomy.Off, 'invalid_bin': Autonomy.Off},
										remapping={'bin_location': 'bin_location', 'agv_id': 'agv_id', 'overzet_type': 'overzet_type', 'camera_ref_frame': 'camera_ref_frame', 'agv_predrop': 'agv_predrop', 'camera_frame': 'camera_frame', 'arm_id_pre': 'arm_id_drop', 'camera_topic': 'camera_topic', 'config_name': 'config_name', 'move_group_prefix': 'move_group_prefix'})

			# x:35 y:369
			OperatableStateMachine.add('BinLocation',
										MessageState(),
										transitions={'continue': 'Move_groupTest'},
										autonomy={'continue': Autonomy.Off},
										remapping={'message': 'bin_location'})

			# x:1438 y:94
			OperatableStateMachine.add('MovePreGrasp2',
										SrdfStateToMoveitAriac(),
										transitions={'reached': 'OverzetKeuze', 'planning_failed': 'WaitRetry2', 'control_failed': 'WaitRetry2', 'param_error': 'failed'},
										autonomy={'reached': Autonomy.Off, 'planning_failed': Autonomy.Off, 'control_failed': Autonomy.Off, 'param_error': Autonomy.Off},
										remapping={'config_name': 'config_name', 'move_group': 'move_group', 'move_group_prefix': 'move_group_prefix', 'action_topic': 'action_topic', 'robot_name': 'robot_name', 'config_name_out': 'config_name_out', 'move_group_out': 'move_group_out', 'robot_name_out': 'robot_name_out', 'action_topic_out': 'action_topic_out', 'joint_values': 'joint_values', 'joint_names': 'joint_names'})

			# x:1671 y:124
			OperatableStateMachine.add('WaitRetry2',
										WaitState(wait_time=5),
										transitions={'done': 'MovePreGrasp2'},
										autonomy={'done': Autonomy.Off})

			# x:1440 y:252
			OperatableStateMachine.add('OverzetPosities',
										OverzetPositieState(),
										transitions={'overzet_begin': 'SetArmNumber', 'invalid_overzet': 'failed'},
										autonomy={'overzet_begin': Autonomy.Off, 'invalid_overzet': Autonomy.Off},
										remapping={'overzet_type': 'overzet_type', 'drop_position': 'drop_position', 'camera_topic_overzet': 'camera_topic_overzet', 'camera_frame_overzet': 'camera_frame_overzet', 'camera_ref_frame_overzet': 'camera_ref_frame_overzet', 'predrop1': 'predrop1', 'pregrasp1': 'pregrasp1', 'arm_id_drop': 'arm_id_drop', 'arm_id_grasp': 'arm_id_grasp'})

			# x:230 y:18
			OperatableStateMachine.add('ConveyorBelt',
										SetConveyorbeltPowerState(),
										transitions={'continue': 'CameraBinChoice', 'fail': 'failed'},
										autonomy={'continue': Autonomy.Off, 'fail': Autonomy.Off},
										remapping={'power': 'conveyor_belt_power'})

			# x:630 y:17
			OperatableStateMachine.add('MovePreGrasp1',
										SrdfStateToMoveitAriac(),
										transitions={'reached': 'DetectCameraPart', 'planning_failed': 'WaitRetry1', 'control_failed': 'WaitRetry1', 'param_error': 'failed'},
										autonomy={'reached': Autonomy.Off, 'planning_failed': Autonomy.Off, 'control_failed': Autonomy.Off, 'param_error': Autonomy.Off},
										remapping={'config_name': 'config_name', 'move_group': 'move_group', 'move_group_prefix': 'move_group_prefix', 'action_topic': 'action_topic', 'robot_name': 'robot_name', 'config_name_out': 'config_name_out', 'move_group_out': 'move_group_out', 'robot_name_out': 'robot_name_out', 'action_topic_out': 'action_topic_out', 'joint_values': 'joint_values', 'joint_names': 'joint_names'})

			# x:974 y:15
			OperatableStateMachine.add('ComputePick',
										ComputeGraspAriacState(joint_names=['linear_arm_actuator_joint', 'shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']),
										transitions={'continue': 'MoveToPick1', 'failed': 'failed'},
										autonomy={'continue': Autonomy.Off, 'failed': Autonomy.Off},
										remapping={'move_group': 'move_group', 'move_group_prefix': 'move_group_prefix', 'tool_link': 'tool_link', 'pose': 'part_pick_pose', 'offset': 'part_offset', 'rotation': 'part_rotation', 'joint_values': 'joint_values', 'joint_names': 'joint_names'})

			# x:1441 y:336
			OperatableStateMachine.add('MovePreDrop',
										SrdfStateToMoveitAriac(),
										transitions={'reached': 'MoveToDrop', 'planning_failed': 'WaitRetry4', 'control_failed': 'WaitRetry4', 'param_error': 'failed'},
										autonomy={'reached': Autonomy.Off, 'planning_failed': Autonomy.Off, 'control_failed': Autonomy.Off, 'param_error': Autonomy.Off},
										remapping={'config_name': 'predrop1', 'move_group': 'move_group', 'move_group_prefix': 'arm_id_drop', 'action_topic': 'action_topic', 'robot_name': 'robot_name', 'config_name_out': 'config_name_out', 'move_group_out': 'move_group_out', 'robot_name_out': 'robot_name_out', 'action_topic_out': 'action_topic_out', 'joint_values': 'joint_values', 'joint_names': 'joint_names'})

			# x:1437 y:173
			OperatableStateMachine.add('OverzetKeuze',
										EqualState(),
										transitions={'true': 'MoveToAGV', 'false': 'OverzetPosities'},
										autonomy={'true': Autonomy.Off, 'false': Autonomy.Off},
										remapping={'value_a': 'overzet_type', 'value_b': 'overzet_not'})

			# x:1676 y:341
			OperatableStateMachine.add('WaitRetry4',
										WaitState(wait_time=2),
										transitions={'done': 'MovePreDrop'},
										autonomy={'done': Autonomy.Off})

			# x:1442 y:416
			OperatableStateMachine.add('MoveToDrop',
										SrdfStateToMoveitAriac(),
										transitions={'reached': 'DisableGripper_2', 'planning_failed': 'WaitRetry4_2', 'control_failed': 'WaitRetry4_2', 'param_error': 'failed'},
										autonomy={'reached': Autonomy.Off, 'planning_failed': Autonomy.Off, 'control_failed': Autonomy.Off, 'param_error': Autonomy.Off},
										remapping={'config_name': 'config_name', 'move_group': 'move_group', 'move_group_prefix': 'arm_id_drop', 'action_topic': 'action_topic', 'robot_name': 'robot_name', 'config_name_out': 'config_name_out', 'move_group_out': 'move_group_out', 'robot_name_out': 'robot_name_out', 'action_topic_out': 'action_topic_out', 'joint_values': 'joint_values', 'joint_names': 'joint_names'})

			# x:1675 y:422
			OperatableStateMachine.add('WaitRetry4_2',
										WaitState(wait_time=2),
										transitions={'done': 'MoveToDrop'},
										autonomy={'done': Autonomy.Off})

			# x:1682 y:665
			OperatableStateMachine.add('WaitRetry1_2',
										WaitState(wait_time=5),
										transitions={'done': 'MovePreGrasp1_2'},
										autonomy={'done': Autonomy.Off})

			# x:1447 y:738
			OperatableStateMachine.add('DetectCameraPart_2',
										DetectPartCameraAriacState(time_out=5.0),
										transitions={'continue': 'ComputePick_2', 'failed': 'failed', 'not_found': 'failed'},
										autonomy={'continue': Autonomy.Off, 'failed': Autonomy.Off, 'not_found': Autonomy.Off},
										remapping={'ref_frame': 'camera_ref_frame_overzet', 'camera_topic': 'camera_topic_overzet', 'camera_frame': 'camera_frame_overzet', 'part': 'part', 'pose': 'part_pick_pose'})

			# x:815 y:660
			OperatableStateMachine.add('Wait_2',
										WaitState(wait_time=1),
										transitions={'done': 'MoveHome_2'},
										autonomy={'done': Autonomy.Off})

			# x:1048 y:658
			OperatableStateMachine.add('WaitRetry3_2',
										WaitState(wait_time=5),
										transitions={'done': 'MoveToPick1_2'},
										autonomy={'done': Autonomy.Off})

			# x:1018 y:739
			OperatableStateMachine.add('MoveToPick1_2',
										MoveitToJointsDynAriacState(),
										transitions={'reached': 'EnableGripper_2', 'planning_failed': 'WaitRetry3_2', 'control_failed': 'EnableGripper_2'},
										autonomy={'reached': Autonomy.Off, 'planning_failed': Autonomy.Off, 'control_failed': Autonomy.Off},
										remapping={'move_group_prefix': 'arm_id_grasp', 'move_group': 'move_group', 'action_topic': 'action_topic', 'joint_values': 'joint_values', 'joint_names': 'joint_names'})

			# x:803 y:739
			OperatableStateMachine.add('EnableGripper_2',
										VacuumGripperControlState(enable=True),
										transitions={'continue': 'Wait_2', 'failed': 'failed', 'invalid_arm_id': 'failed'},
										autonomy={'continue': Autonomy.Off, 'failed': Autonomy.Off, 'invalid_arm_id': Autonomy.Off},
										remapping={'arm_id': 'arm_id_grasp'})

			# x:1446 y:658
			OperatableStateMachine.add('MovePreGrasp1_2',
										SrdfStateToMoveitAriac(),
										transitions={'reached': 'DetectCameraPart_2', 'planning_failed': 'WaitRetry1_2', 'control_failed': 'WaitRetry1_2', 'param_error': 'failed'},
										autonomy={'reached': Autonomy.Off, 'planning_failed': Autonomy.Off, 'control_failed': Autonomy.Off, 'param_error': Autonomy.Off},
										remapping={'config_name': 'pregrasp1', 'move_group': 'move_group', 'move_group_prefix': 'arm_id_grasp', 'action_topic': 'action_topic', 'robot_name': 'robot_name', 'config_name_out': 'config_name_out', 'move_group_out': 'move_group_out', 'robot_name_out': 'robot_name_out', 'action_topic_out': 'action_topic_out', 'joint_values': 'joint_values', 'joint_names': 'joint_names'})

			# x:1249 y:739
			OperatableStateMachine.add('ComputePick_2',
										ComputeGraspAriacState(joint_names=['linear_arm_actuator_joint', 'shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']),
										transitions={'continue': 'MoveToPick1_2', 'failed': 'failed'},
										autonomy={'continue': Autonomy.Off, 'failed': Autonomy.Off},
										remapping={'move_group': 'move_group', 'move_group_prefix': 'move_group_prefix', 'tool_link': 'tool_link', 'pose': 'part_pick_pose', 'offset': 'part_offset', 'rotation': 'part_rotation', 'joint_values': 'joint_values', 'joint_names': 'joint_names'})

			# x:1442 y:496
			OperatableStateMachine.add('DisableGripper_2',
										VacuumGripperControlState(enable=False),
										transitions={'continue': 'MoveHome', 'failed': 'failed', 'invalid_arm_id': 'failed'},
										autonomy={'continue': Autonomy.Off, 'failed': Autonomy.Off, 'invalid_arm_id': Autonomy.Off},
										remapping={'arm_id': 'arm_id_drop'})

			# x:1679 y:575
			OperatableStateMachine.add('WaitRetry1_3',
										WaitState(wait_time=5),
										transitions={'done': 'MoveHome'},
										autonomy={'done': Autonomy.Off})

			# x:1445 y:573
			OperatableStateMachine.add('MoveHome',
										SrdfStateToMoveitAriac(),
										transitions={'reached': 'MovePreGrasp1_2', 'planning_failed': 'WaitRetry1_3', 'control_failed': 'WaitRetry1_3', 'param_error': 'failed'},
										autonomy={'reached': Autonomy.Off, 'planning_failed': Autonomy.Off, 'control_failed': Autonomy.Off, 'param_error': Autonomy.Off},
										remapping={'config_name': 'config_name_home', 'move_group': 'move_group', 'move_group_prefix': 'arm_id_drop', 'action_topic': 'action_topic', 'robot_name': 'robot_name', 'config_name_out': 'config_name_out', 'move_group_out': 'move_group_out', 'robot_name_out': 'robot_name_out', 'action_topic_out': 'action_topic_out', 'joint_values': 'joint_values', 'joint_names': 'joint_names'})

			# x:775 y:577
			OperatableStateMachine.add('MoveHome_2',
										SrdfStateToMoveitAriac(),
										transitions={'reached': 'MoveToAGV', 'planning_failed': 'WaitRetry3_2_2', 'control_failed': 'WaitRetry3_2_2', 'param_error': 'MoveToAGV'},
										autonomy={'reached': Autonomy.Off, 'planning_failed': Autonomy.Off, 'control_failed': Autonomy.Off, 'param_error': Autonomy.Off},
										remapping={'config_name': 'config_name_home', 'move_group': 'move_group', 'move_group_prefix': 'arm_id_grasp', 'action_topic': 'action_topic', 'robot_name': 'robot_name', 'config_name_out': 'config_name_out', 'move_group_out': 'move_group_out', 'robot_name_out': 'robot_name_out', 'action_topic_out': 'action_topic_out', 'joint_values': 'joint_values', 'joint_names': 'joint_names'})

			# x:1008 y:598
			OperatableStateMachine.add('WaitRetry3_2_2',
										WaitState(wait_time=5),
										transitions={'done': 'MoveHome_2'},
										autonomy={'done': Autonomy.Off})

			# x:772 y:482
			OperatableStateMachine.add('MoveToAGV',
										SrdfStateToMoveitAriac(),
										transitions={'reached': 'ComputeDropPartPlace', 'planning_failed': 'WaitRetry1_4', 'control_failed': 'WaitRetry1_4', 'param_error': 'failed'},
										autonomy={'reached': Autonomy.Off, 'planning_failed': Autonomy.Off, 'control_failed': Autonomy.Off, 'param_error': Autonomy.Off},
										remapping={'config_name': 'agv_predrop', 'move_group': 'move_group', 'move_group_prefix': 'move_group_prefix', 'action_topic': 'action_topic', 'robot_name': 'robot_name', 'config_name_out': 'config_name_out', 'move_group_out': 'move_group_out', 'robot_name_out': 'robot_name_out', 'action_topic_out': 'action_topic_out', 'joint_values': 'joint_values', 'joint_names': 'joint_names'})

			# x:779 y:375
			OperatableStateMachine.add('WaitRetry1_4',
										WaitState(wait_time=5),
										transitions={'done': 'MoveToAGV'},
										autonomy={'done': Autonomy.Off})

			# x:547 y:480
			OperatableStateMachine.add('ComputeDropPartPlace',
										ComputeGraspPartOffsetAriacState(joint_names=['linear_arm_actuator_joint', 'shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']),
										transitions={'continue': 'DisableGripper', 'failed': 'failed'},
										autonomy={'continue': Autonomy.Off, 'failed': Autonomy.Off},
										remapping={'move_group': 'move_group', 'move_group_prefix': 'move_group_prefix', 'tool_link': 'tool_link', 'pose': 'pose_on_agv', 'offset': 'offset', 'rotation': 'part_rotation', 'part_pose': 'pose_on_agv', 'joint_values': 'joint_values', 'joint_names': 'joint_names'})

			# x:1643 y:251
			OperatableStateMachine.add('SetArmNumber',
										ReplaceState(),
										transitions={'done': 'MovePreDrop'},
										autonomy={'done': Autonomy.Off},
										remapping={'value': 'arm_id_grasp', 'result': 'move_group_prefix'})

			# x:204 y:218
			OperatableStateMachine.add('Move_groupTest',
										MessageState(),
										transitions={'continue': 'ConveyorBelt'},
										autonomy={'continue': Autonomy.Off},
										remapping={'message': 'move_group'})


		return _state_machine


	# Private functions can be added inside the following tags
	# [MANUAL_FUNC]
	
	# [/MANUAL_FUNC]
